# Solitary Confinement

## Authors
- @Goofables
- @B00TK1D
## Description

You tried to collect $200 on your way to jail.  Now you're in solitary confinement.  Might as well start working out...
